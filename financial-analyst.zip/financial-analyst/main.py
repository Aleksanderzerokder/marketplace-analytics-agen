# main.py
from fastapi import FastAPI
from pydantic import BaseModel
from agents.sales_agent import SalesAgent
from agents.price_agent import PriceAgent
from agents.ads_agent import AdsAgent
from agents.card_agent import CardAgent
from agents.reviews_agent import ReviewsAgent
from agents.profit_agent import ProfitAgent
from agents.audience_agent import AudienceAgent
from decision_agent.manager import DecisionAgent

app = FastAPI()

class AnalyzeRequest(BaseModel):
    marketplace: str
    period_days: int
    sku_list: list[str] | str  # может быть "all"

@app.post("/analyze")
def analyze(request: AnalyzeRequest):
    sku = request.sku_list[0] if isinstance(request.sku_list, list) else "test-sku"

    agent_results = {
        "sales": SalesAgent(sku, request.marketplace, request.period_days).run(),
        "price": PriceAgent(sku, request.marketplace, request.period_days).run(),
        "ads": AdsAgent(sku, request.marketplace, request.period_days).run(),
        "card": CardAgent(sku, request.marketplace, request.period_days).run(),
        "reviews": ReviewsAgent(sku, request.marketplace, request.period_days).run(),
        "profit": ProfitAgent(sku, request.marketplace, request.period_days).run(),
        "audience": AudienceAgent(sku, request.marketplace, request.period_days).run()
    }

    summary = DecisionAgent(agent_results).generate_summary()
    return summary

# agents/sales_agent.py
class SalesAgent:
    def __init__(self, sku: str, marketplace: str, period: int):
        self.sku = sku
        self.marketplace = marketplace
        self.period = period

    def run(self):
        return {
            "sku": self.sku,
            "marketplace": self.marketplace,
            "trend": "снижение",
            "avg_sales": 5.2,
            "ctr": 0.7,
            "recommendation": "Проверьте видимость и обложку товара."
        }

# agents/price_agent.py
class PriceAgent:
    def __init__(self, sku: str, marketplace: str, period: int):
        self.sku = sku
        self.marketplace = marketplace
        self.period = period

    def run(self):
        return {
            "price_compared": "выше на 10%",
            "recommendation": "Снизьте цену на 5% для повышения конкурентоспособности."
        }

# agents/ads_agent.py
class AdsAgent:
    def __init__(self, sku: str, marketplace: str, period: int):
        self.sku = sku
        self.marketplace = marketplace
        self.period = period

    def run(self):
        return {
            "roas": 1.2,
            "recommendation": "Оптимизируйте рекламный бюджет, отключите неэффективные ключи."
        }

# agents/card_agent.py
class CardAgent:
    def __init__(self, sku: str, marketplace: str, period: int):
        self.sku = sku
        self.marketplace = marketplace
        self.period = period

    def run(self):
        return {
            "title_score": 6,
            "has_video": False,
            "recommendation": "Добавьте видео и улучшите заголовок с ключевыми словами."
        }

# agents/reviews_agent.py
class ReviewsAgent:
    def __init__(self, sku: str, marketplace: str, period: int):
        self.sku = sku
        self.marketplace = marketplace
        self.period = period

    def run(self):
        return {
            "negative_rate": 0.25,
            "recommendation": "Ответьте на негативные отзывы и устраните повторяющиеся жалобы."
        }

# agents/profit_agent.py
class ProfitAgent:
    def __init__(self, sku: str, marketplace: str, period: int):
        self.sku = sku
        self.marketplace = marketplace
        self.period = period

    def run(self):
        return {
            "profit_margin": 0.18,
            "recommendation": "Рассмотрите возможность сокращения издержек или логистики."
        }

# agents/audience_agent.py
class AudienceAgent:
    def __init__(self, sku: str, marketplace: str, period: int):
        self.sku = sku
        self.marketplace = marketplace
        self.period = period

    def run(self):
        return {
            "audience_type": "женщины 25–44",
            "recommendation": "Добавьте акценты на подарок, пользу для здоровья и упаковку."
        }

# decision_agent/manager.py
class DecisionAgent:
    def __init__(self, results: dict):
        self.results = results

    def generate_summary(self):
        recommendations = []

        for aspect, data in self.results.items():
            rec = data.get("recommendation")
            if rec:
                recommendations.append(f"{aspect.capitalize()}: {rec}")

        return {
            "sku": self.results["sales"].get("sku"),
            "marketplace": self.results["sales"].get("marketplace"),
            "recommendations": recommendations,
            "raw_data": self.results
        }
